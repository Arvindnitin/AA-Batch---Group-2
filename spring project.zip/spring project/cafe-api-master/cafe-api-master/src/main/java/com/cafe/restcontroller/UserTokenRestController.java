package com.cafe.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cafe.config.JwtTokenUtil;
import com.cafe.entity.User;
import com.cafe.service.UserService;


@RestController
@RequestMapping("/api/v1")
public class UserTokenRestController {

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private UserService userService;

	@GetMapping("/users/user/{token}")
	public ResponseEntity<User> getUserDetails(@PathVariable("token") String token) {
		try {
			String emailId = jwtTokenUtil.getUsernameFromToken(token);
			User user = userService.findByUserName(emailId);
			user.setPassword("");
			return new ResponseEntity<User>(user, HttpStatus.OK);
		} catch (Exception e) {
			return null;
		}
	}

}
