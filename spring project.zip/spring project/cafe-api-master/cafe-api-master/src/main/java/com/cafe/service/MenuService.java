package com.cafe.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.cafe.entity.Menu;
import com.cafe.exception.MenuNotFoundException;

public interface MenuService {

	public Menu save(Menu menu);
	
	public List<Menu> findAll();
	
	public Menu findById(long id) throws MenuNotFoundException;

	public int updateMenu(long id, String name, Float price, String description) throws MenuNotFoundException;
	
	public void deleteMenu(long id) throws MenuNotFoundException;
	
	public Page<Menu> findAll(int page, int size );
}
