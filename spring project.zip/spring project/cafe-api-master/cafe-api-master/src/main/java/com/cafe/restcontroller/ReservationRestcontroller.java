package com.cafe.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cafe.entity.Category;
import com.cafe.entity.Reservation;
import com.cafe.exception.ReservationNotFoundException;
import com.cafe.service.ReservationService;

@RestController
@RequestMapping("/api/v1")
public class ReservationRestcontroller {

	@Autowired
	private ReservationService reservationService;

	@PostMapping("/reservation")
	public ResponseEntity<Reservation> addReservation(@RequestBody Reservation reservation) {
		return new ResponseEntity<Reservation>(reservationService.save(reservation), HttpStatus.OK);
	}
	
	@GetMapping("/reservations/reservation/{id}")
	public ResponseEntity<Reservation> findReservationById(@PathVariable("id") long id) throws ReservationNotFoundException {
		return new ResponseEntity<Reservation>(reservationService.findById(id), HttpStatus.OK);
	}

	@GetMapping("/reservations")
	public ResponseEntity<List<Reservation>> addReservation() {
		return new ResponseEntity<List<Reservation>>(reservationService.findAll(), HttpStatus.OK);
	}
	
	@GetMapping("/reservations/all")
	public ResponseEntity<Page<Reservation>> findAllMenu(@RequestParam(name="page",required=false,defaultValue="0") int page,
			@RequestParam(name="size",required=false,defaultValue="10") int size) {
		return new ResponseEntity<Page<Reservation>>(reservationService.findAll(page, size), HttpStatus.OK);
	}
	
	@PutMapping("/reservations/reservation/{id}")
	public ResponseEntity<Reservation> updateReservationStatus(@PathVariable("id") long id,@RequestParam("status") boolean status) throws ReservationNotFoundException{
		System.out.println("ID :: "+id+" status::"+status); 
		return new ResponseEntity<Reservation>(reservationService.updateReservationStatus(status, id), HttpStatus.OK);
	}
	
	@DeleteMapping("/reservations/reservation/{id}")
	public ResponseEntity<String> deleteReservationById(@PathVariable("id") long id) throws ReservationNotFoundException {
		reservationService.deleteReservation(id);
		return new ResponseEntity<String>("Reservation has deleted successfully", HttpStatus.OK);
	}
}
