package com.cafe.service.impl;

import java.util.List;
import java.util.Optional;

//import javax.rmi.CORBA.Stub;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.cafe.entity.Reservation;
import com.cafe.exception.ReservationNotFoundException;
import com.cafe.repository.ReservationRepository;
import com.cafe.service.ReservationService;

@Service
public class ReservationServiceImpl implements ReservationService {

	@Autowired
	private ReservationRepository reservationRepository;

	@Override
	public Reservation save(Reservation reservation) {

		return reservationRepository.save(reservation);
	}

	@Override
	public List<Reservation> findAll() {

		return reservationRepository.findAll();
	}

	@Override
	public Reservation updateReservationStatus(boolean status, long id) throws ReservationNotFoundException {
		Optional<Reservation> reservationOptional = reservationRepository.findById(id);
		if (reservationOptional.isPresent()) {
			int result = reservationRepository.updateReservationStatus(status, id);
			System.out.println("UPDATE RESERVATION STATUS :: " + result);
			Reservation reservation = reservationOptional.get();
			reservation.setStatus(status);
			return reservation;
		} else {
			throw new ReservationNotFoundException("Given reservation " + id + " id not exist");
		}
	}

	@Override
	public Reservation findById(long id) throws ReservationNotFoundException {

		return reservationRepository.findById(id)
				.orElseThrow(() -> new ReservationNotFoundException("Given reservation " + id + " id not found."));
	}

	@Override
	public Page<Reservation> findAll(int page, int size) {
		
		return reservationRepository.findAll(PageRequest.of(page, size, Sort.by("id").descending()));
	}

	@Override
	public void deleteReservation(long id) throws ReservationNotFoundException {
	
		findById(id);
		
		
	}
	
	

}
