package com.cafe.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cafe.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	
	User findByUserName(String userName);

	User findByUserNameAndPassword(String emailId, String encodePassword);

	@Transactional
	@Modifying
	@Query("UPDATE User u SET u.userName=:userName WHERE u.id=:id")
	int updateUserName(@Param(value = "userName") String userName, @Param(value = "id") long id);

	@Transactional
	@Modifying
	@Query("UPDATE User u SET u.password=:password WHERE u.id=:id")
	int updateUserPassword(@Param("id") long userId, @Param("password") String encodePassword);

}
