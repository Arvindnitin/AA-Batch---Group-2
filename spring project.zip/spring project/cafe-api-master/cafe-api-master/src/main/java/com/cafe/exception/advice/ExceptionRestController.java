package com.cafe.exception.advice;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cafe.entity.dto.ResponseMessage;
import com.cafe.exception.CategoryNotFoundException;
import com.cafe.exception.JWTTokenNotFound;
import com.cafe.exception.MenuNotFoundException;
import com.cafe.exception.ReservationNotFoundException;

@RestControllerAdvice
public class ExceptionRestController {

	
	@ExceptionHandler({ JWTTokenNotFound.class })
	public ResponseEntity<ResponseMessage> jwtTokenException(JWTTokenNotFound jwtTokenNotFoundException, HttpServletRequest request) {
		System.out.println("TOKEN NOT FOUND EXCEPTION :: " + jwtTokenNotFoundException.getMessage());
		return 
				new ResponseEntity<ResponseMessage>(new ResponseMessage(
				new Date(),
				HttpStatus.UNAUTHORIZED.value(),
				"Token has expired or not found.",
				jwtTokenNotFoundException.getMessage(),
				request.getRequestURI().toString()
				), HttpStatus.UNAUTHORIZED);
	}
	
	@ExceptionHandler({ MenuNotFoundException.class })
	public ResponseEntity<ResponseMessage> menuNotFoundException(MenuNotFoundException menuNotFoundException, HttpServletRequest request) {
		
		return 
				new ResponseEntity<ResponseMessage>(new ResponseMessage(
				new Date(),
				HttpStatus.NOT_FOUND.value(),
				"Menu has not found.",
				menuNotFoundException.getMessage(),
				request.getRequestURI().toString()
				), HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler({ ReservationNotFoundException.class })
	public ResponseEntity<ResponseMessage> reservationNotFoundException(ReservationNotFoundException reservationNotFoundException, HttpServletRequest request) {
		
		return 
				new ResponseEntity<ResponseMessage>(new ResponseMessage(
				new Date(),
				HttpStatus.NOT_FOUND.value(),
				"Reservation not found.",
				reservationNotFoundException.getMessage(),
				request.getRequestURI().toString()
				), HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler({ CategoryNotFoundException.class })
	public ResponseEntity<ResponseMessage> categoryNotFoundException(CategoryNotFoundException categoryNotFoundException, HttpServletRequest request) {
		
		return 
				new ResponseEntity<ResponseMessage>(new ResponseMessage(
				new Date(),
				HttpStatus.NOT_FOUND.value(),
				"Category not found.",
				categoryNotFoundException.getMessage(),
				request.getRequestURI().toString()
				), HttpStatus.NOT_FOUND);
	}
}
