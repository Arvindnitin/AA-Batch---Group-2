package com.cafe.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cafe.entity.Menu;
import com.cafe.exception.MenuNotFoundException;
import com.cafe.service.MenuService;

@RestController
@RequestMapping("/api/v1")
public class MenuRestController {
	
	@Autowired
	private MenuService menuService;
	
	@PostMapping("/menu")
	public ResponseEntity<Menu> addMenu(@RequestBody Menu menu) {
		return new ResponseEntity<Menu>(menuService.save(menu), HttpStatus.OK);
	}
	
	@GetMapping("/menus")
	public ResponseEntity<List<Menu>> getAllMenu() {
		return new ResponseEntity<List<Menu>>(menuService.findAll(), HttpStatus.OK);
	}
	
	@GetMapping("/menus/all")
	public ResponseEntity<Page<Menu>> findAllMenu(@RequestParam(name="page",required=false,defaultValue="0") int page,
			@RequestParam(name="size",required=false,defaultValue="10") int size) {
		return new ResponseEntity<Page<Menu>>(menuService.findAll(page, size), HttpStatus.OK);
	}
	
	@GetMapping("/menu/{id}")
	public ResponseEntity<Menu> getMenuById(@PathVariable("id") long id) throws MenuNotFoundException {
		return new ResponseEntity<Menu>(menuService.findById(id), HttpStatus.OK);
	}
	
	@PutMapping("/menus/menu/{id}")
	public ResponseEntity<Menu> updateMenu(@PathVariable("id") long id, @RequestBody Menu menu) throws MenuNotFoundException {
		menuService.updateMenu(id, menu.getName(), menu.getPrice(), menu.getDescription());
		return new ResponseEntity<Menu>(menuService.findById(id), HttpStatus.OK);
	}
	
	@DeleteMapping("/menus/menu/{id}")
	public ResponseEntity<String> deleteMenu(@PathVariable("id") long id) throws MenuNotFoundException {
		menuService.deleteMenu(id);
		return new ResponseEntity<String>("Menu has deleted successfully.", HttpStatus.OK);
	}
}
