package com.cafe.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cafe.entity.User;
import com.cafe.exception.UserException;
import com.cafe.exception.UserNotFoundException;
import com.cafe.repository.UserRepository;
import com.cafe.service.UserService;


@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder bcryptEncoder;

	@Transactional
	@Override
	public User save(User user) throws UserException {
		User dbUser = userRepository.findByUserName(user.getUserName());
		if (dbUser == null) {
			String encodePassword = bcryptEncoder.encode(user.getPassword());
			user.setPassword(encodePassword);
			user.setRegisterDate(new Date());
			return userRepository.save(user);
		} else {
			throw new UserException("User name have already registred.");
		}
	}

	@Override
	public User findById(long userId) throws UserNotFoundException {
		Optional<User> userOptional = userRepository.findById(userId);
		if (userOptional.isPresent()) {
			return userOptional.get();
		} else
			throw new UserNotFoundException("User not found by given " + userId + " id");
	}

	@Override
	public List<User> findAll() {

		return userRepository.findAll(Sort.by(Order.desc("userId")));
	}

	@Override
	public User findByUserNameAndPassword(String emailId, String password) {
		String encodePassword = bcryptEncoder.encode(password);
		return userRepository.findByUserNameAndPassword(emailId, encodePassword);
	}

	@Override
	public User findByUserName(String userName) throws UsernameNotFoundException {
		User user = userRepository.findByUserName(userName);
		if (user != null)
			return user;
		else
			throw new UsernameNotFoundException("User name not found.");
	}

	@Override
	public User updateUserPassword(long userId, String password) throws UserNotFoundException {
		String encodePassword = bcryptEncoder.encode(password);
		userRepository.updateUserPassword(userId, encodePassword);
		Optional<User> userOptional = userRepository.findById(userId);
		if (userOptional.isPresent())
			return userOptional.get();
		else 
			throw new UserNotFoundException("Given user id not exist.");
	}

	@Override
	public Page<User> findByAll(int page, int size) {
		
		return userRepository.findAll(PageRequest.of(page, size, Sort.by("id").descending()));
	}
	
	

}
