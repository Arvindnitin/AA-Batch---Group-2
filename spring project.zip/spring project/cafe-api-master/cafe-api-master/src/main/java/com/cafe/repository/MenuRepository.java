package com.cafe.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cafe.entity.Menu;

@Repository
public interface MenuRepository extends JpaRepository<Menu, Long>{
	@Transactional
	@Modifying
	@Query("UPDATE Menu m SET m.name=:name,m.price=:price,m.description=:description WHERE m.id=:id")
	int updateMenu(@Param(value = "name") String name,@Param(value = "price") Float price,@Param(value = "description") String description, @Param(value = "id") long id);

}
