package com.cafe.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cafe.entity.Reservation;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Long> {
	@Transactional
	@Modifying
	@Query("UPDATE Reservation r SET r.status=:status WHERE r.id=:id")
	int updateReservationStatus(@Param(value = "status") boolean status, @Param(value = "id") long id);

}
