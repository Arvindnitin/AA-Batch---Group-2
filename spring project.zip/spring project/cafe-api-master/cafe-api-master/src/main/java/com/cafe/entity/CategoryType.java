package com.cafe.entity;

public enum CategoryType {
  BREAK_FAST,LUNCH,BREAK
}
