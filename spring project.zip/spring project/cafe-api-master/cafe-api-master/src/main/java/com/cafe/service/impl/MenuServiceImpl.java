package com.cafe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.cafe.entity.Menu;
import com.cafe.exception.MenuNotFoundException;
import com.cafe.repository.MenuRepository;
import com.cafe.service.MenuService;

@Service
public class MenuServiceImpl implements MenuService {

	@Autowired
	private MenuRepository menuRepository;
	
	@Override
	public Menu save(Menu menu) {
		
		return menuRepository.save(menu);
	}

	@Override
	public List<Menu> findAll() {
		
		return menuRepository.findAll();
	}

	@Override
	public Menu findById(long id) throws MenuNotFoundException {
		return menuRepository.findById(id).orElseThrow(()->new MenuNotFoundException("Given menu id "+id+" not found"));
	}

	@Override
	public int updateMenu(long id, String name, Float price, String description) throws MenuNotFoundException {
		findById(id);
		return menuRepository.updateMenu(name, price, description, id);
	}

	@Override
	public void deleteMenu(long id) throws MenuNotFoundException {
		findById(id);
		menuRepository.deleteById(id);
	}

	@Override
	public Page<Menu> findAll(int page, int size) {
		
		return menuRepository.findAll(PageRequest.of(page, size, Sort.by("id").descending()));
	}
	
	

}
