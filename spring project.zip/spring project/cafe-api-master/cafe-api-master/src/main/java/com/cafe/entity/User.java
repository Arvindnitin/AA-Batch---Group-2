package com.cafe.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class User {

	@Id
	@GeneratedValue
	private long id;
	private String firstname;
	private String phoneNumber;
	private String userName;
	private String password;
	private String location;
	private String role;
	private Date registerDate;

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	

	public Date getRegisterDate() {
		return registerDate;
	}

	public void setRegisterDate(Date registerDate) {
		this.registerDate = registerDate;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", firstname=" + firstname + ", phoneNumber=" + phoneNumber + ", userName=" + userName
				+ ", location=" + location + ", role=" + role + "]";
	}
	
	public User(String firstname, String phoneNumber, String userName, String password, String location, String role) {
		super();
		this.firstname = firstname;
		this.phoneNumber = phoneNumber;
		this.userName = userName;
		this.password = password;
		this.location = location;
		this.role = role;
	}

	public User() {

	}

}
