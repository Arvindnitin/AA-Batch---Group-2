package com.cafe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.cafe.entity.Category;
import com.cafe.exception.CategoryNotFoundException;
import com.cafe.repository.CategoryRepository;
import com.cafe.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryRepository categoryRepository;

	@Override
	public Category save(Category category) {

		return categoryRepository.save(category);
	}

	@Override
	public List<Category> findAll() {

		return categoryRepository.findAll();
	}

	@Override
	public Category findById(long id) throws CategoryNotFoundException {

		return categoryRepository.findById(id)
				.orElseThrow(() -> new CategoryNotFoundException("Given category " + id + " not found"));
	}

	@Override
	public int updateCategory(long id, String type) throws CategoryNotFoundException {
		findById(id);
		return categoryRepository.updateCategory(type, id);
	}

	@Override
	public void deleteCategory(long id) {
		categoryRepository.deleteById(id);
	}

	@Override
	public Page<Category> findAll(int page, int size) {
		
		return categoryRepository.findAll(PageRequest.of(page, size, Sort.by("id").descending()));
	}

}
