package com.cafe.exception;

public class UserNotFoundException extends Exception {
	private static final long serialVersionUID = 7791808341881572813L;

	public UserNotFoundException(String message) {
		super(message);
	}


}
