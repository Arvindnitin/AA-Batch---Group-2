package com.cafe.exception;

public class JWTTokenNotFound extends RuntimeException {

	private static final long serialVersionUID = -3072336121918081676L;
    
	public JWTTokenNotFound(String message) {
		super(message);
	}
}
