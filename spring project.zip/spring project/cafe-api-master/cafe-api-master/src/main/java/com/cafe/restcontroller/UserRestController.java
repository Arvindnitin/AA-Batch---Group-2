package com.cafe.restcontroller;

import java.text.ParseException;
import java.util.Objects;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cafe.config.JwtTokenUtil;
import com.cafe.entity.User;
import com.cafe.entity.dto.Token;
import com.cafe.exception.UserException;
import com.cafe.service.UserService;
import com.cafe.exception.UserNotFoundException;


@CrossOrigin(origins= {"*"})
@RestController
public class UserRestController {
	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private UserService userService;
	
	@Autowired
	private UserDetailsService jwtInMemoryUserDetailsService;

	Logger log = LogManager.getLogger(UserRestController.class.getName());

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody User authenticationRequest) throws Exception {
		authenticate(authenticationRequest.getUserName(), authenticationRequest.getPassword());
		final UserDetails userDetails = jwtInMemoryUserDetailsService
				.loadUserByUsername(authenticationRequest.getUserName());
		final String token = jwtTokenUtil.generateToken(userDetails);
		User user = userService.findByUserName(authenticationRequest.getUserName());
		HttpHeaders headers = new HttpHeaders();
		headers.add("Set-Cookie","token="+token+"; Max-Age=604800; Path=/; Secure; HttpOnly");
		return ResponseEntity.status(HttpStatus.OK).headers(headers).body(new Token(token, user.getRole()));
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ResponseEntity<?> saveUser(@RequestBody User user) throws UserException, ParseException{
		User dbUser = userService.save(user);
		if (dbUser != null) {
			return new ResponseEntity<String>(new String("You have regstred successfully."), HttpStatus.OK);
		} else {
			throw new UserException("You have not registred.");
		}
	}
	
	

	private void authenticate(String username, String password) throws Exception {
		Objects.requireNonNull(username);
		Objects.requireNonNull(password);

		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			throw new Exception("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			throw new Exception("INVALID_CREDENTIALS", e);
		}
	}
	
	@GetMapping("/api/v1/users")
	public ResponseEntity<Page<User>> findByUsers(
			@RequestParam(name="page",required=false,defaultValue="0") int page,
			@RequestParam(name="size",required=false,defaultValue="10") int size
			) {
		
		return new ResponseEntity<Page<User>>(userService.findByAll(page, size), HttpStatus.OK);
	}

	@GetMapping("/api/v1/user/{id}")
	public ResponseEntity<User> findById(@PathVariable("id") long userId) throws UserNotFoundException {
		return new ResponseEntity<User>(userService.findById(userId), HttpStatus.OK);
	}
}
