package com.cafe.service;

import java.text.ParseException;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.cafe.entity.User;
import com.cafe.exception.UserException;
import com.cafe.exception.UserNotFoundException;

public interface UserService {

	public User save(User user) throws UserException, ParseException;

	public User findById(long userId) throws UserNotFoundException;

	public List<User> findAll();

	public User findByUserName(String emailId) throws UsernameNotFoundException;

	public User findByUserNameAndPassword(String userName, String password);
	
	public User updateUserPassword(long userId, String password) throws UserNotFoundException;
	
	public Page<User> findByAll( int page , int size );

}
