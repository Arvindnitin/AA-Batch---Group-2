package com.cafe.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cafe.entity.Category;
import com.cafe.entity.Menu;
import com.cafe.exception.CategoryNotFoundException;
import com.cafe.service.CategoryService;

@RestController
@RequestMapping("/api/v1")
public class CategoryRestcontroller {

	@Autowired
	private CategoryService categoryService;

	@PostMapping("/category")
	public ResponseEntity<Category> addCategory(@RequestBody Category category) {
		return new ResponseEntity<Category>(categoryService.save(category), HttpStatus.OK);
	}

	@GetMapping("/category/{id}")
	public ResponseEntity<Category> findCategoryById(@PathVariable("id") long id) throws CategoryNotFoundException {
		return new ResponseEntity<Category>(categoryService.findById(id), HttpStatus.OK);
	}
	
	@GetMapping("/categories")
	public ResponseEntity<List<Category>> findAllCategory() {
		return new ResponseEntity<List<Category>>(categoryService.findAll(), HttpStatus.OK);
	}
	
	@GetMapping("/categories/all")
	public ResponseEntity<Page<Category>> findAllMenu(@RequestParam(name="page",required=false,defaultValue="0") int page,
			@RequestParam(name="size",required=false,defaultValue="10") int size) {
		return new ResponseEntity<Page<Category>>(categoryService.findAll(page, size), HttpStatus.OK);
	}

	@PutMapping("/categories/category/{id}")
	public ResponseEntity<Category> updateCategory(@PathVariable("id") long id, @RequestParam("type") String type)
			throws CategoryNotFoundException {
		int result = categoryService.updateCategory(id, type);
		if (result == 1) {
			Category category = categoryService.findById(id);
			category.setType(type);
			return new ResponseEntity<Category>(category, HttpStatus.OK);
		} else
			return new ResponseEntity<Category>(categoryService.findById(id), HttpStatus.OK);
	}
	
	@DeleteMapping("/categories/category/{id}")
	public ResponseEntity<String> deleteCategory(@PathVariable("id") long id)
			throws CategoryNotFoundException {
			categoryService.findById(id);
			categoryService.deleteCategory(id);
		return new ResponseEntity<String>("Category has deleted successfully.", HttpStatus.OK);
	
	}
}
