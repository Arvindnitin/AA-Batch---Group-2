package com.cafe.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.cafe.entity.Reservation;
import com.cafe.exception.ReservationNotFoundException;

public interface ReservationService {

	public Reservation save(Reservation reservation);
	
	public List<Reservation> findAll();
	
	public Reservation updateReservationStatus(boolean status, long id) throws ReservationNotFoundException;
	
	public Reservation findById(long id) throws ReservationNotFoundException;

	public Page<Reservation> findAll(int page, int size);

	public void deleteReservation(long id) throws ReservationNotFoundException;
	
}
