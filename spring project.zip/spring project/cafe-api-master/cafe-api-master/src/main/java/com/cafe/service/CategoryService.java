package com.cafe.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.cafe.entity.Category;
import com.cafe.exception.CategoryNotFoundException;

public interface CategoryService {

	public Category save(Category category);
	
	public List<Category> findAll();

	public Category findById(long id) throws CategoryNotFoundException;

	public int updateCategory(long id, String type) throws CategoryNotFoundException;
	
	public void deleteCategory(long id);

	public Page<Category> findAll(int page, int size);
}
