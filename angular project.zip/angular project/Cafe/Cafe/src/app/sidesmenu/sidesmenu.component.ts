import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidesmenu',
  templateUrl: './sidesmenu.component.html',
  styleUrls: ['./sidesmenu.component.css']
})
export class SidesmenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
