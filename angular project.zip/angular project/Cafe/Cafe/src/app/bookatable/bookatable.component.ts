import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookatable',
  templateUrl: './bookatable.component.html',
  styleUrls: ['./bookatable.component.css']
})
export class BookatableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
