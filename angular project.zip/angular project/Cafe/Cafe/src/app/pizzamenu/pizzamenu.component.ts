import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pizzamenu',
  templateUrl: './pizzamenu.component.html',
  styleUrls: ['./pizzamenu.component.css']
})
export class PizzamenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
