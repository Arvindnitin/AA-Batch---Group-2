import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addmenu',
  templateUrl: './addmenu.component.html',
  styleUrls: ['./addmenu.component.css']
})
export class AddmenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
