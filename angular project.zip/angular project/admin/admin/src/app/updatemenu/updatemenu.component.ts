import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatemenu',
  templateUrl: './updatemenu.component.html',
  styleUrls: ['./updatemenu.component.css']
})
export class UpdatemenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
